
# Infovelvora LLC - Next.js Project

This is a modern, responsive business website for **Infovelvora LLC**, built with **Next.js 14** and **Tailwind CSS**.

## 🚀 Features
- Next.js 14 + React 18
- Tailwind CSS for modern UI
- Responsive and mobile-friendly
- SEO optimized
- Ready for Vercel deployment

## 📌 Installation

```bash
npm install
npm run dev
```

## 🌐 Deployment on Vercel

1. Go to [Vercel](https://vercel.com/)
2. Create a new project
3. Import this repository from GitHub
4. Click **Deploy**

The site will be live instantly!
    